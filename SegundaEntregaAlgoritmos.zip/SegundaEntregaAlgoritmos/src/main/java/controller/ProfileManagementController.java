package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import ucr.proyecto1.domain.TXTData.InformationUserXML;
import ucr.proyecto1.domain.data.User;
import ucr.proyecto1.domain.list.ListException;

public class ProfileManagementController {

    @FXML
    private TextField txtField_userName;
    @FXML
    private TextField txtField_email;
    @FXML
    private ComboBox<String> cBoxRole;

    private InformationUserXML informationUserXML = new InformationUserXML();
    private User selectedUser;
    @FXML
    private TextField txtField_idUser;

    @FXML
    public void initialize() {
        // Inicializa el ComboBox con roles, si es necesario.
        cBoxRole.getItems().addAll("Admin", "User", "Instructor");

        txtField_idUser.setEditable(false);

    }

    // Método para cargar la información del usuario seleccionado en los campos de texto.
    public void loadUserData(User user) {
        System.out.println("Cargando datos del usuario: " + user.getName());
        this.selectedUser = user;
        txtField_idUser.setText(String.valueOf(user.getId()));
        txtField_userName.setText(user.getName());
        txtField_email.setText(user.getEmail());
        cBoxRole.setValue(user.getRole());
    }

    @FXML
    public void updateOnAction(ActionEvent actionEvent) {
        if (selectedUser != null) {
            String name = txtField_userName.getText();
            String email = txtField_email.getText();
            String role = cBoxRole.getValue();
            int id = selectedUser.getId(); // Obtén el ID del usuario seleccionado

            informationUserXML.updateInformation(role, id, name, email);
            System.out.println("Se ha modificado exitosamente.");


        } else {
            System.out.println("No user selected.");
        }
    }

}
