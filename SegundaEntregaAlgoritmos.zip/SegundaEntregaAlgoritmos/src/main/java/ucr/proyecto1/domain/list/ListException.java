package ucr.proyecto1.domain.list;

public class ListException extends Exception {

    public ListException(String message) {
        super(message);
    }
}

