package ucr.proyecto1.domain.tree;

public class TreeException extends Exception {
    public TreeException(String message) {
        super(message);
    }
}
